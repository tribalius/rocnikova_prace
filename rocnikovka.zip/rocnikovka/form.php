<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Nový člověk</title>
        <style type="text/css">@import url("css.css");</style>
    </head>
    <body>    
        <h1>Nový člověk</h1>
        <div>
        <form action="index.php" method="post" name="novy">
            Jméno: <br><input type="text" name="jmeno"> <br>
            Příjmení:<br><input type="text" name="prijmeni"><br>
            Stát: <br><input type="text" name="stat"><br>
            Umělecké jméno / Skupina:<br><input type="text" name="artist"><br>
            <input type="submit" value="Přidat">
        </form>
        </div>


    </body>
</html>
